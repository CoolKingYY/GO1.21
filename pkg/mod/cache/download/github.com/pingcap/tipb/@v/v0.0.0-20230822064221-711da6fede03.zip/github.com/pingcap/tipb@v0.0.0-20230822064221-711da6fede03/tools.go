//+build tools

package tipb

import (
	_ "github.com/gogo/protobuf/protoc-gen-gofast"
	_ "golang.org/x/tools/cmd/goimports"
)
