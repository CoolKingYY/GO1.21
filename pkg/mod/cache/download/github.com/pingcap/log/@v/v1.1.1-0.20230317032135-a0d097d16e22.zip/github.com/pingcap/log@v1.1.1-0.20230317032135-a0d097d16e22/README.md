# pingcap/log

A wrapper library based on `go.uber.org/zap`.

