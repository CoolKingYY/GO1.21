[← Timeout](5-Timeout-EN.md) | Debug[(中文)](6-Debug-CN.md) | [Logger →](7-Logger-EN.md)
***

# Debugging
If there is an environment variable `DEBUG=sdk` , all requests will enable debug mode.

***
[← Timeout](5-Timeout-EN.md) | Debug[(中文)](6-Debug-CN.md) | [Logger →](7-Logger-EN.md)
