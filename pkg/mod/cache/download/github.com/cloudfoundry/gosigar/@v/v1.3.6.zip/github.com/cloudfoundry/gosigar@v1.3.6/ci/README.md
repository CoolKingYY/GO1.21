# Steps for Configuring the Pipeline

Follow the steps in [BOSH: Configuring Concourse Pipelines](https://github.com/cloudfoundry/bosh/blob/develop/docs/configuring_concourse_pipelines.md), using "gosigar" as the value for `PROJECT_NAME`.
