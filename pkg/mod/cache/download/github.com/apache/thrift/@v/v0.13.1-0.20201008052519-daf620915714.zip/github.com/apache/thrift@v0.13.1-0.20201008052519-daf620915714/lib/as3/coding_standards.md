Please follow [General Coding Standards](/doc/coding_standards.md)
