union union_name {
  1: optional bool return=1
}
