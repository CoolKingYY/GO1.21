//go:build !windows

package sentry

func onProfilerStart() {}
