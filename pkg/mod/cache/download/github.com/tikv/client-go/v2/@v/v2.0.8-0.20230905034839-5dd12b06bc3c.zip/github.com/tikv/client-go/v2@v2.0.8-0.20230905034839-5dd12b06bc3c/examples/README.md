# TiKV Go Client Example

TiKV Go Client Example provides examples for [TiKV Go Client](https://github.com/tikv/client-go)

## Developing 
### Building Examples:

To build `examples/rawkv`:

```bash
cd ./examples/rawkv
go mod tidy
go build
```