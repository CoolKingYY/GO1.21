package apicodec

import (
	"testing"
)

func TestV1DecodeBucketKey(t *testing.T) {
}
