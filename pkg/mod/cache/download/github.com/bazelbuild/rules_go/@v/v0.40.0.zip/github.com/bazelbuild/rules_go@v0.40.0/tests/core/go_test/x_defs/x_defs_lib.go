package x_defs_lib

var LibGo = "not set"
