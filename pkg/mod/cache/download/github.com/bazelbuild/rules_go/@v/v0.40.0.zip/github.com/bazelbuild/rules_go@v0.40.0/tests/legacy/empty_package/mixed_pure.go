//+build !cgo

package mixed

var Value = 1
