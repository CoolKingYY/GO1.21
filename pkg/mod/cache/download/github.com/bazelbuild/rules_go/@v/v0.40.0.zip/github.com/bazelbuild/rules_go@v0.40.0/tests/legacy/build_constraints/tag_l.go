// +build linux

package build_constraints

var tag = "linux"
