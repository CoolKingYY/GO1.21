package platform_lib

const Platform = "darwin"
