package c

import (
	"testing"
)

func TestC(t *testing.T) {
	C()
}
