package a

func Answer() int { return 42 }
