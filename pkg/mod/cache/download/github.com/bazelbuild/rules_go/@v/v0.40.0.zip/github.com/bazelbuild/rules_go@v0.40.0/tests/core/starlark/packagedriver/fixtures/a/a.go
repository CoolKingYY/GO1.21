package a

func A() {
	return
}
