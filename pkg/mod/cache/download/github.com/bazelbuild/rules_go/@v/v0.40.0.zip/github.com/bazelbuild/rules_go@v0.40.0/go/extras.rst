.. _extras.md: /docs/go/extras/extras.md

This file has moved, please find it at extras.md_.
