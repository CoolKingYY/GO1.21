#include <stdio.h>

void native_greeting(void) {
    printf("Hello, world!\n");
}
