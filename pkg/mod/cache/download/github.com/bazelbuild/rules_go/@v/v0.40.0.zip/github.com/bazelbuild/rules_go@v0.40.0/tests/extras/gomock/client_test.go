package client

var _ Client = (*MockClient)(nil)
