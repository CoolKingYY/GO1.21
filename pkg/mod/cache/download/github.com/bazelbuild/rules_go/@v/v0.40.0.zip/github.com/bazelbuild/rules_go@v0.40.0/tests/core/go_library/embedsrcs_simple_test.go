package embedsrcs_simple_test

import _ "embed"

//go:embed embedsrcs_static/no
var no []byte
