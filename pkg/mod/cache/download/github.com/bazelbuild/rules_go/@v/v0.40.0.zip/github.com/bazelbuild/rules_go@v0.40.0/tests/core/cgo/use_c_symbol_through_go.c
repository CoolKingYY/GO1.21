#include "tests/core/cgo/use_transitive_symbol.h"

int main() {
    PrintGreeting();
}
