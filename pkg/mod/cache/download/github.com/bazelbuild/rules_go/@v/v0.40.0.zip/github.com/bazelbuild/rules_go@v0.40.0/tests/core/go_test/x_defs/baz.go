package baz

import "github.com/bazelbuild/rules_go/tests/core/go_test/x_defs/qux"

var Baz string
var Qux = qux.Qux
