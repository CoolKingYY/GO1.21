package testdata

//go:dosomething
