#!/usr/bin/env sh
${BIN} "$@"
