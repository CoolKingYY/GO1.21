# Clock

This package provides an interface for time-based operations.  It allows
mocking time for testing.
